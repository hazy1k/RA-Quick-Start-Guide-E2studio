/********************************************************************
 * 共建开源生态是我们的目标。为此我们努力把性价比和颜值做到极致。
 * 同时全面开放原理图、PCB等所有软硬件资料。
 * 提供交流平台、免费训练营、开发者扶持计划等，让您能够尽情发挥您的才华。
 * 我们坚信自由和定制化是开源生态的核心。
 * 我们只是抛砖引玉，期望能够激发出更多的创意和想法。
 * 我们渴望与志同道合的伙伴们携手合作，共同探索无限可能。
 * 让我们各展所长，共同建设一个强大的开源生态系统。
 * 立创·地奇星RA6E2开发板等待着您的加入。
 * 让我们一起推动技术的前进，一起创未来！
 *********************************************************************
 * 立创开发板不靠卖板赚钱，以培养中国工程师为己任。  
 * 开发板官网：www.lckfb.com
 * 嘉立创论坛：www.jlc-bbs.com/lckfb 
 * 资料教程：wiki.lckfb.com  
 * 关注B站：【立创开发板】，掌握我们的最新动态！  
 *********************************************************************/
#include "Apply/app.h"         // 应用层
#include "seg/bsp_seg.h"       // 数码管驱动
#include "gpt/bsp_gpt.h"       // 通用定时器驱动
#include "adc/bsp_adc.h"       // ADC（模数转换）驱动
#include "uart/bsp_uart.h"     // UART（串口）驱动
#include "led/bsp_led.h"       // LED 驱动  

extern uint8_t Seg_Reg[6];  // 数码管显示寄存器
unsigned int timecount=0;    // 主循环计时计数器

uint16_t V_Buffer=0;        // 缓存电压值

/**
 * @brief 硬件初始化函数
 * @details 初始化系统所需的外设
 *          读取历史校准数据并计算校准斜率，为系统运行做准备。
 */
void bsp_Init(void)
{
	UART0_Init();					// 初始化串口0	
    GPT_Init();						// 初始化通用定时器
    ADC_Init();						// 初始化ADC模块
                    
}

/**
 * @brief   运用函数
 * @details 运行逻辑
 */
void Run(void)
{
    bsp_Init();         // 初始化硬件外设
  
	DisplayI(000);  //最下面显示 000

    while(1)
    {
        V_Buffer = ADC_read_Value() * 3.3 / 40.96;                   //将采集的数据扩大100倍，能显示小数点后两位

        if( timecount >= 500)
        {
			
            printf("temperature=%d\r\n",V_Buffer);

			Display(V_Buffer);					  //更新数码管显示

			P402_Toggle;  //工作指示灯
			timecount=0;
        }


    }
}
