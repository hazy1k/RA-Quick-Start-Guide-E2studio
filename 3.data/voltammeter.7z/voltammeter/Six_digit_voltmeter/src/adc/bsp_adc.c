/********************************************************************
 * 共建开源生态是我们的目标。为此我们努力把性价比和颜值做到极致。
 * 同时全面开放原理图、PCB等所有软硬件资料。
 * 提供交流平台、免费训练营、开发者扶持计划等，让您能够尽情发挥您的才华。
 * 我们坚信自由和定制化是开源生态的核心。
 * 我们只是抛砖引玉，期望能够激发出更多的创意和想法。
 * 我们渴望与志同道合的伙伴们携手合作，共同探索无限可能。
 * 让我们各展所长，共同建设一个强大的开源生态系统。
 * 立创·地奇星RA6E2开发板等待着您的加入。
 * 让我们一起推动技术的前进，一起创未来！
 *********************************************************************
 * 立创开发板不靠卖板赚钱，以培养中国工程师为己任。  
 * 开发板官网：www.lckfb.com
 * 嘉立创论坛：www.jlc-bbs.com/lckfb 
 * 资料教程：wiki.lckfb.com  
 * 关注B站：【立创开发板】，掌握我们的最新动态！  
 *********************************************************************/
#include "bsp_adc.h"
#include "r_adc_api.h"
#include "hal_data.h"
#include <stdio.h>

volatile bool adc_flag = false;

void ADC_Init(void)
{
    fsp_err_t err;

    // 打开ADC设备
    err = R_ADC_Open(&g_adc0_ctrl, &g_adc0_cfg);
    if (FSP_SUCCESS != err) {
        printf("ADC初始化失败! \n");
        return;

    }

    // 配置ADC扫描
    err = R_ADC_ScanCfg(&g_adc0_ctrl, &g_adc0_channel_cfg);
    if (FSP_SUCCESS != err) {
        printf("ADC扫描配置失败! \n");
        R_ADC_Close(&g_adc0_ctrl);  // 关闭已打开的ADC
        return;
    }

    printf("ADC初始化成功!\n");
}

void adc_callback(adc_callback_args_t *p_args)
{
    FSP_PARAMETER_NOT_USED(p_args);
        adc_flag = true;
}

uint16_t ADC_read_Value(void)
{
    uint16_t adc_data = 0;

    // 启动ADC扫描
    fsp_err_t err = R_ADC_ScanStart(&g_adc0_ctrl);
    if (FSP_SUCCESS != err) {
        printf("ADC扫描启动失败! \n");
        return 9999;  // 返回错误值
    }

    // 等待ADC转换完成
    while (!adc_flag);
    adc_flag = false;  // 清除标志位

    // 读取ADC数据
    err = R_ADC_Read(&g_adc0_ctrl, ADC_CHANNEL_2, &adc_data);
    if (FSP_SUCCESS != err) {
        printf("ADC数据读取失败!\n");
        return 9999;  // 返回错误值
    }

    return adc_data;
}
