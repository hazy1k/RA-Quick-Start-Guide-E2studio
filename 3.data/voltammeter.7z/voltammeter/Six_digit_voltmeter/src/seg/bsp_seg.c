/********************************************************************
 * 共建开源生态是我们的目标。为此我们努力把性价比和颜值做到极致。
 * 同时全面开放原理图、PCB等所有软硬件资料。
 * 提供交流平台、免费训练营、开发者扶持计划等，让您能够尽情发挥您的才华。
 * 我们坚信自由和定制化是开源生态的核心。
 * 我们只是抛砖引玉，期望能够激发出更多的创意和想法。
 * 我们渴望与志同道合的伙伴们携手合作，共同探索无限可能。
 * 让我们各展所长，共同建设一个强大的开源生态系统。
 * 立创·地奇星RA6E2开发板等待着您的加入。
 * 让我们一起推动技术的前进，一起创未来！
 *********************************************************************
 * 立创开发板不靠卖板赚钱，以培养中国工程师为己任。  
 * 开发板官网：www.lckfb.com
 * 嘉立创论坛：www.jlc-bbs.com/lckfb 
 * 资料教程：wiki.lckfb.com  
 * 关注B站：【立创开发板】，掌握我们的最新动态！  
 *********************************************************************/
#include <seg/bsp_seg.h>

#include "hal_data.h"

/*  共阴数码管编码表：
 0x3f   0x06   0x5b  0x4f  0x66  0x6d  0x7d  0x07  0x7f  0x6f 
  0      1      2     3     4     5     6     7     8     9 
 0xbf   0x86   0xdb  0xcf  0xe6  0xed  0xfd  0x87  0xff  0xef           
  0.     1.     2.    3.    4.    5.    6.    7.    8.    9.          */
 
             
uint8_t Seg_Table[21] = {0x3f, 0x06, 0x5b, 0x4f, 0x66, 0x6d, 0x7d, 0x07, 0x7f, 0x6f,
	0xbf, 0x86, 0xdb, 0xcf, 0xe6, 0xed, 0xfd, 0x87, 0xff, 0xef,0xF7};// 0xF7:A.
uint8_t Seg_Reg[6] = {1,2,3,4,5,6};


void Seg_Dis(uint8_t Pos,uint8_t Num)
{
	int i;
	uint8_t Dis_Value;
	Dis_Value = Seg_Table[Num];
	
	for(i = 0; i < 8; i++)
	{
      switch(i)
        {
          case 0:
                R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_03_PIN_02, (Dis_Value >> i) & 0x01);//P,A
              break;
          case 1:
              R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_02_PIN_07, (Dis_Value >> i) & 0x01);//P,B
              break;
          case 2:
              R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_01_PIN_02, (Dis_Value >> i) & 0x01);//P,C
              break;
          case 3:
              R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_01_PIN_04, (Dis_Value >> i) & 0x01);//P,D
              break;
          case 4:
              R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_03_PIN_01, (Dis_Value >> i) & 0x01);//P,E
              break;
          case 5:
              R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_02_PIN_06, (Dis_Value >> i) & 0x01);//P,F
              break;
          case 6:
              R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_01_PIN_12, (Dis_Value >> i) & 0x01);//P,G
              break;
          case 7:
              R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_01_PIN_03, (Dis_Value >> i) & 0x01);//P,DP
              break;

          default:
              break;
				}
	}
	
	switch(Pos)
	{
	  case 0:
        R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_01_PIN_09, BSP_IO_LEVEL_LOW); //P,COM1
      break;
    case 1:
		  R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_01_PIN_10,BSP_IO_LEVEL_LOW);  //P,COM2
      break;
    case 2:
		 R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_01_PIN_11,BSP_IO_LEVEL_LOW);  //P,COM3
      break;
		case 3:
		  R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_04_PIN_08,BSP_IO_LEVEL_LOW); //P,COM4
      break;
    case 4:
		  R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_04_PIN_09,BSP_IO_LEVEL_LOW); //P,COM5
      break;
    case 5:
		  R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_04_PIN_03,BSP_IO_LEVEL_LOW);  //P,COM6
      break;
		default:
      break;
	}
}

/**
 * @brief 关闭所有公共端
 * 
 */
void Close_Com(void)
{
        R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_01_PIN_09, BSP_IO_LEVEL_HIGH); //P,COM1
		R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_01_PIN_10,BSP_IO_LEVEL_HIGH);  //P,COM2
		R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_01_PIN_11,BSP_IO_LEVEL_HIGH);  //P,COM3
		R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_04_PIN_08,BSP_IO_LEVEL_HIGH); //P,COM4
		R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_04_PIN_09,BSP_IO_LEVEL_HIGH); //P,COM5
		R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_04_PIN_03,BSP_IO_LEVEL_HIGH);  //P,COM6
}

void DisplaySETV(uint32_t value)
{
	uint8_t Thousands;
  uint8_t Hundreds;
  uint8_t Tens;
  uint8_t Units; // 个位数
	
	Thousands = value / 1000;
	 if(Thousands > 0)
    {
       Units     = value % 10;
       value     = Units > 5 ? (value + 10) : value; // 根据后一位四舍五入
       Thousands = value / 1000 % 10;
       Hundreds  = value / 100 % 10;
       Tens      = value / 10 % 10;
			
       // 显示xx.x伏
       Seg_Reg[3] = Thousands;
       Seg_Reg[4] = Hundreds + 10; // 加dp显示
       Seg_Reg[5] = Tens;
		}
		
	 else
	   {
	     Units     = value % 10;
	     Tens      = value / 10 % 10;
       Hundreds  = value / 100 % 10;
	     
			 // 显示x.xx伏
	     Seg_Reg[3] = Hundreds + 10;              // 加dp显示
	     Seg_Reg[4] = Tens;
	     Seg_Reg[5] = Units;
	   }
}

void Display(uint32_t value)
{
	uint8_t Thousands;
  uint8_t Hundreds;
  uint8_t Tens;
  uint8_t Units; // 个位数
	Thousands = value / 1000;
	 if(Thousands > 0)
    {
       Units     = value % 10;
       value     = Units > 5 ? (value + 10) : value; // 根据后一位四舍五入
       Thousands = value / 1000 % 10;
       Hundreds  = value / 100 % 10;
       Tens      = value / 10 % 10;
			
       // 显示xx.x伏
       Seg_Reg[0] = Thousands;
       Seg_Reg[1] = Hundreds + 10; // 加dp显示
       Seg_Reg[2] = Tens;
		}
		
	 else
	   {
	     Units     = value % 10;
	     Tens      = value / 10 % 10;
       Hundreds  = value / 100 % 10;
	     
			 // 显示x.xx伏
	     Seg_Reg[0] = Hundreds + 10;              // 加dp显示
	     Seg_Reg[1] = Tens;
	     Seg_Reg[2] = Units;
	   }
}

void DisplayI(uint32_t value)
{
	uint8_t Thousands;
  uint8_t Hundreds;
  uint8_t Tens;
  uint8_t Units; // 个位数
	
	     Seg_Reg[3] = value/100 + 10;// 加dp显示
       Seg_Reg[4] = value%100/10; 
       Seg_Reg[5] = value%10;	
}

void DisplayValue(uint32_t value)
{
	uint8_t SWwei;
	uint8_t Wwei;
	uint8_t Thousands;
  uint8_t Hundreds;
  uint8_t Tens;
  uint8_t Units; // 个位数
	
	     SWwei		 = value / 100000;
			 Wwei			 = value / 10000 %10+10;
			 Thousands = value / 1000 % 10;
       Hundreds  = value / 100 % 10;
       Tens      = value / 10 % 10;
			 Units 		 = value % 10;
	Seg_Reg[0] =SWwei;
	Seg_Reg[1] =Wwei;	
	Seg_Reg[2] =Thousands;	
	Seg_Reg[3] =Hundreds;	
	Seg_Reg[4] =Tens;
	Seg_Reg[5] =Units;
}

/**
 * @brief 数码管扫描显示函数,定时器周期性调用
 *
 */
void Dis_Refresh(void)
{
  static uint8_t num = 0;

	Close_Com();//先关闭公共端,防止重影
	Seg_Dis(num,Seg_Reg[num]);
	num++;
  if(num > 6)
  {
    num = 0;
  }
}

