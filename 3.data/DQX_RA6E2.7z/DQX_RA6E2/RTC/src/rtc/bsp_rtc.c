/********************************************************************
 * 共建开源生态是我们的目标。为此我们努力把性价比和颜值做到极致。
 * 同时全面开放原理图、PCB等所有软硬件资料。
 * 提供交流平台、免费训练营、开发者扶持计划等，让您能够尽情发挥您的才华。
 * 我们坚信自由和定制化是开源生态的核心。
 * 我们只是抛砖引玉，期望能够激发出更多的创意和想法。
 * 我们渴望与志同道合的伙伴们携手合作，共同探索无限可能。
 * 让我们各展所长，共同建设一个强大的开源生态系统。
 * 立创·地奇星RA6E2开发板等待着您的加入。
 * 让我们一起推动技术的前进，一起创未来！
 *********************************************************************
 * 立创开发板不靠卖板赚钱，以培养中国工程师为己任。  
 * 开发板官网：www.lckfb.com
 * 嘉立创论坛：www.jlc-bbs.com/lckfb 
 * 资料教程：wiki.lckfb.com  
 * 关注B站：【立创开发板】，掌握我们的最新动态！  
 *********************************************************************/
#include "bsp_rtc.h"


const char* Convet_tsr[7] = {"一","二","三","四","五","六","天"};

/* 中断标志位 */
bool Rtc_Flag_Interr = false;
static rtc_time_t Get_Current_Time;


/* 初始化时间设置 */
static  rtc_time_t Set_Init_Time = {
    .tm_sec = 40,       // 秒
    .tm_min = 59,      // 分
    .tm_hour = 23,     // 小时
    .tm_wday = 2,      // 星期
    .tm_mday = 15,     // 日
    .tm_mon = 7,       // 月
    .tm_year = 2025 - YEAR_FIXED  // 年份
};

/**
 * @brief RTC实时时钟初始化函数
 * @details 初始化RTC模块，设置初始时间
 */
void RTC_Init(void)
{
    /* 初始化RTC */
    fsp_err_t err = R_RTC_Open(g_rtc0.p_ctrl, g_rtc0.p_cfg);
    if (FSP_SUCCESS != err) {
        printf("错误：RTC初始化中断设置失败\n");
    }

    /* 设置RTC计时 */
        err = R_RTC_CalendarTimeSet(g_rtc0.p_ctrl, &Set_Init_Time);
        if (FSP_SUCCESS != err) {
            printf("错误：RTC计时设置失败\n");
        }

    /* 使能计时中断 */
        err = R_RTC_PeriodicIrqRateSet(g_rtc0.p_ctrl, RTC_PERIODIC_IRQ_SELECT_1_SECOND);
        if (FSP_SUCCESS != err) {
            printf("错误：RTC中断设置失败\n");
        }

}

/**
 * @brief 获取当前RTC时间
 * @details 当RTC中断标志位有效时，将最新时间复制到输出参数
 * @param Nne_time 用于存储当前时间的结构体指针
 * @return 成功获取时间返回true，否则返回false
 */
bool Rtc_GetTime(rtc_time_t *Nne_time)
{
    if (Rtc_Flag_Interr)
    {
        /* 复制当前时间 */
        *Nne_time = Get_Current_Time;
        /* 清除中断标志位 */
        Rtc_Flag_Interr = false;
        return true;
    }
    return false;
}

/**
 * @brief RTC中断回调函数
 * @details 当RTC产生周期中断时触发，用于更新当前时间并设置标志位
 * @param p_args 中断事件参数结构体，包含事件类型等信息
 */
void rtc_callback(rtc_callback_args_t *p_args)
{
    if (p_args->event = RTC_EVENT_PERIODIC_IRQ)
    {
        /* 获取当前时间 */
        fsp_err_t err = R_RTC_CalendarTimeGet(g_rtc0.p_ctrl, &Get_Current_Time);
        if (FSP_SUCCESS != err) {
            printf("错误：获取时间失败\n");
        }

        /* 标记时间更新 */
        Rtc_Flag_Interr = true;
    }
}

/**
 * @brief 格式化RTC时间为字符串
 * @details 将rtc_time_t结构体中的时间信息转换为"YYYY-MM-DD HH:MM:SS 星期X"格式的字符串
 * @param time 指向包含时间信息的结构体指针
 * @param buffer 用于存储格式化字符串的缓冲区
 * @param size 缓冲区的大小，防止溢出
 */
void FormatRtcTime(const rtc_time_t *time, char *buffer, size_t size)
{

    int wday = time->tm_wday - 1;
    if (wday < 0 || wday > 7) wday = 0;  // 超出范围时默认取第一个

    if (time && buffer && size > 0) {
        snprintf(buffer, size, "%.4d-%.2d-%.2d %.2d:%.2d:%.2d 星期:%s",
                 time->tm_year + YEAR_FIXED,
                 time->tm_mon,
                 time->tm_mday,
                 time->tm_hour,
                 time->tm_min,
                 time->tm_sec,
                 Convet_tsr[wday]
                 );
    }
}
